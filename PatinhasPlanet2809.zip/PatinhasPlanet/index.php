<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patinhas Planet - Bem-vindo</title>
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHq6v2B5a6UY41A+F8L5EdwK4PmctkChdy0UlkbI6CjURbUJz4tZBpQHJ3H+i6v6l+F4Hpcw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Reseta estilos */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
        }

        /* Header */
        header {
            background-color: #333;
            color: #fff;
            padding: 1rem 0;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 80%;
            margin: auto;
            max-width: 1200px;
        }

        header h1 {
            font-size: 2rem;
        }

        header nav ul {
            list-style: none;
            display: flex;
        }

        header nav ul li {
            margin-right: 1.5rem;
        }

        header nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 1rem;
        }

        .auth-buttons .btn {
            color: #fff;
            background-color: #555;
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 5px;
            margin-left: 1rem;
            transition: background-color 0.3s ease;
        }

        .auth-buttons .btn:hover {
            background-color: #666;
        }

        /* Hero Section */
        .hero {
            background: url('images/hero-bg.jpg') no-repeat center center/cover;
            color: #fff;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 0 2rem;
            position: relative;
            margin-top: 60px;
            /* Para ajustar o espaço do header fixo */
        }

        .hero h2 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .hero p {
            font-size: 1.2rem;
            margin-bottom: 2rem;
        }

        .btn-hero {
            background-color: #007bff;
            color: #fff;
            padding: 0.8rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-hero:hover {
            background-color: #0056b3;
        }

        /* Sections */
        section {
            padding: 4rem 0;
        }

        .container {
            width: 80%;
            margin: auto;
            max-width: 1200px;
        }

        #about,
        #services,
        #contact {
            text-align: center;
        }

        #services .service-cards {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        #services .card {
            background-color: #fff;
            padding: 2rem;
            margin: 1rem;
            flex: 1;
            min-width: 250px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
            transition: box-shadow 0.3s ease;
        }

        #services .card i {
            font-size: 3rem;
            color: #007bff;
            margin-bottom: 1rem;
        }

        #services .card h3 {
            margin-bottom: 1rem;
        }

        #services .card:hover {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }

        /* Contato Section */
        #contact p {
            margin-bottom: 1rem;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem 0;
            position: relative;
            bottom: 0;
            left: 0;
            width: 100%;
        }

        footer p {
            margin: 0;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            header nav ul {
                flex-direction: column;
                align-items: center;
            }

            header nav ul li {
                margin: 0.5rem 0;
            }

            .hero h2 {
                font-size: 2.5rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .btn-hero {
                padding: 0.6rem 1.2rem;
            }

            #services .service-cards {
                flex-direction: column;
            }

            #services .card {
                min-width: 100%;
            }
        }
    </style>
</head>

<body>

    <!-- Header -->
    <header>
        <div class="container">
            <h1>Patinhas Planet</h1>
            <nav>
                <ul>
                    <li><a href="#about">Sobre Nós</a></li>
                    <li><a href="#services">Serviços</a></li>
                    <li><a href="#contact">Contato</a></li>
                </ul>
                <div class="auth-buttons">
                    <a href="/PatinhasPlanet/pages/login.php" class="btn">Login</a>
                    <a href="/PatinhasPlanet/pages/cadastro.php" class="btn">Cadastro</a>

                </div>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h2>Bem-vindo ao Patinhas Planet</h2>
            <p>O melhor cuidado para seu pet em um só lugar.</p>
            <a href="cadastro.php" class="btn btn-hero">Cadastre-se Agora</a>
        </div>
    </section>

    <!-- Sobre Nós Section -->
    <section id="about">
        <div class="container">
            <h2>Sobre Nós</h2>
            <p>Conheça mais sobre o Patinhas Planet e nossa missão de cuidar do seu pet.</p>
        </div>
    </section>

    <!-- Serviços Section -->
    <section id="services">
        <div class="container">
            <h2>Nossos Serviços</h2>
            <div class="service-cards">
                <div class="card">
                    <i class="fas fa-shower"></i>
                    <h3>Banho e Tosa</h3>
                    <p>O melhor cuidado com profissionais experientes.</p>
                </div>
                <div class="card">
                    <i class="fas fa-stethoscope"></i>
                    <h3>Consultas Veterinárias</h3>
                    <p>Cuidado especializado para a saúde do seu pet.</p>
                </div>
                <div class="card">
                    <i class="fas fa-syringe"></i>
                    <h3>Vacinação</h3>
                    <p>Proteja seu pet com nossas vacinas de alta qualidade.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contato Section -->
    <section id="contact">
        <div class="container">
            <h2>Contato</h2>
            <p>Entre em contato conosco para mais informações.</p>
            <a href="contact.php" class="btn">Fale Conosco</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2024 Patinhas Planet. Todos os direitos reservados.</p>
        </div>
    </footer>

</body>

</html>