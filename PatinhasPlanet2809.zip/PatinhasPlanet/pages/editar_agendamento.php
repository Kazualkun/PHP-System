<?php
include('../config/config.php');
session_start();

if (isset($_GET['id_agendamento'])) {
    $id_agendamento = intval($_GET['id_agendamento']);
    
    // Buscar dados do agendamento atual
    $sql = "SELECT data, hora, tipo_servico FROM agendamentos WHERE id_agendamento = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $id_agendamento);
    $stmt->execute();
    $result = $stmt->get_result();
    $agendamento = $result->fetch_assoc();
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Atualizar agendamento
        $nova_data = $_POST['data'];
        $nova_hora = $_POST['hora'];
        $novo_tipo_servico = $_POST['tipo_servico'];

        $sql_update = "UPDATE agendamentos SET data = ?, hora = ?, tipo_servico = ? WHERE id_agendamento = ?";
        $stmt_update = $conexao->prepare($sql_update);
        $stmt_update->bind_param("sssi", $nova_data, $nova_hora, $novo_tipo_servico, $id_agendamento);

        if ($stmt_update->execute()) {
            echo "Agendamento atualizado com sucesso.";
            header("Location: prontuario.php"); // Redireciona de volta após editar
            exit();
        } else {
            echo "Erro ao atualizar agendamento.";
        }
    }
} else {
    echo "Agendamento não encontrado.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Agendamento</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Editar Agendamento</h2>
    <form method="POST">
        <label for="data">Data:</label>
        <input type="date" name="data" value="<?php echo htmlspecialchars($agendamento['data']); ?>" required>
        
        <label for="hora">Hora:</label>
        <input type="time" name="hora" value="<?php echo htmlspecialchars($agendamento['hora']); ?>" required>
        
        <label for="tipo_servico">Tipo de Serviço:</label>
        <select name="tipo_servico">
            <option value="banho" <?php if ($agendamento['tipo_servico'] === 'banho') echo 'selected'; ?>>Banho</option>
            <option value="tosa" <?php if ($agendamento['tipo_servico'] === 'tosa') echo 'selected'; ?>>Tosa</option>
            <option value="consulta" <?php if ($agendamento['tipo_servico'] === 'consulta') echo 'selected'; ?>>Consulta</option>
            <option value="cirurgia" <?php if ($agendamento['tipo_servico'] === 'cirurgia') echo 'selected'; ?>>Cirurgia</option>
        </select>

        <button type="submit">Salvar Alterações</button>
    </form>
</body>
</html>
