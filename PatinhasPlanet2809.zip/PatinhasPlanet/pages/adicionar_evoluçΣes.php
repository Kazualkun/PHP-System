<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evoluções</title>
    <link rel="stylesheet" href="../css/styles.css"> <!-- Link para o seu CSS -->
    <style>
        /* Estilo básico */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        h1 {
            color: #333;
            margin-bottom: 10px;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: #007BFF;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button.btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }

        button.btn:hover {
            background-color: #0056b3;
        }

        .success-message {
            color: #28a745;
            font-weight: bold;
            margin-top: 15px;
        }

        .error-message {
            color: #dc3545;
            font-weight: bold;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php
        // Incluir arquivo de configuração do banco de dados
        include('../config/config.php');
        session_start();

        // Verificar se o veterinário está logado
        if (!isset($_SESSION['id_usuario'])) {
            header("Location: login.php");
            exit();
        }

        // Receber o ID do pet via GET
        $id_pet = $_GET['id_pet'] ?? null;

        if ($id_pet) {
            // Consultar o pet pelo ID
            $sql_pet = "SELECT nome_pet FROM pets WHERE id_pet = ?";
            $stmt_pet = $conexao->prepare($sql_pet);
            $stmt_pet->bind_param("i", $id_pet);
            $stmt_pet->execute();
            $resultado_pet = $stmt_pet->get_result();
            $pet = $resultado_pet->fetch_assoc();

            // Cabeçalho com navegação
            echo '<header>
                <h1>Evoluções</h1>
                <h2>Pet: ' . htmlspecialchars($pet['nome_pet']) . '</h2>
                <nav>
                    <a href="prontuarios.php?id_pet=' . htmlspecialchars($id_pet) . '">Prontuários</a>
                    <a href="adicionar_exames.php?id_pet=' . htmlspecialchars($id_pet) . '">Adicionar Exame</a>
                    <a href="estoque.php">Estoque</a>
                    <a href="logout.php">Logout</a>
                </nav>
              </header>';

            // Formulário para adicionar evolução
            echo '<h2>Adicionar Evolução</h2>';
            echo '<form action="" method="POST">
                <div class="form-group">
                    <label>Descrição da Evolução:</label>
                    <textarea name="descricao" required></textarea>
                </div>
                <button type="submit" class="btn">Adicionar Evolução</button>
            </form>';

            // Processar o formulário ao ser enviado
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $descricao = $_POST['descricao'];
                $data = date('Y-m-d H:i:s'); // Captura a data atual

                // Inserir evolução no banco de dados
                $sql = "INSERT INTO evolucoes (id_pet, data, descricao) VALUES (?, ?, ?)";
                $stmt = $conexao->prepare($sql);
                $stmt->bind_param("iss", $id_pet, $data, $descricao);

                if ($stmt->execute()) {
                    echo '<p class="success-message">Evolução adicionada com sucesso!</p>';
                } else {
                    echo '<p class="error-message">Erro ao adicionar evolução: ' . htmlspecialchars($conexao->error) . '</p>';
                }
            }
        } else {
            echo "<p class='error-message'>ID do pet não fornecido.</p>";
        }
        ?>
    </div>
</body>

</html>
