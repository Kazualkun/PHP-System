<?php
// Incluir arquivo de configuração do banco de dados
include('../config/config.php');
session_start();

// Verificar se o veterinário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Inicializar variáveis
$mensagem_sucesso = '';
$mensagem_erro = '';

// Verificar se o ID do pet foi passado como parâmetro
if (!isset($_GET['id_pet']) || empty($_GET['id_pet'])) {
    header("Location: historico.php"); // Redirecionar se o ID do pet não for fornecido
    exit();
}

$id_pet = intval($_GET['id_pet']); // Captura o ID do pet da URL
$nome_pet = $_GET['nome_pet'] ?? ''; // Captura o nome do pet da URL

// Processar o formulário ao ser submetido
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Captura os dados do formulário
    $descricao = $_POST['descricao'] ?? '';
    $data = $_POST['data'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $observacoes = $_POST['observacoes'] ?? '';

    // Adicionando o ID do veterinário da sessão
    $id_veterinario = $_SESSION['id_usuario'];

    // Ajustar a data para o formato DATETIME (Y-m-d H:i:s)
    $data = $data . ' 00:00:00';

    // Inserir os dados no banco
    $sql_insert = "INSERT INTO cirurgias (id_pet, id_veterinario, descricao, data, tipo, observacoes) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conexao->prepare($sql_insert);

    if ($stmt_insert) {
        $stmt_insert->bind_param("iissss", $id_pet, $id_veterinario, $descricao, $data, $tipo, $observacoes);
        
        if ($stmt_insert->execute()) {
            $mensagem_sucesso = "Cirurgia adicionada com sucesso!";
        } else {
            $mensagem_erro = "Erro ao adicionar cirurgia: " . $stmt_insert->error;
        }
    } else {
        $mensagem_erro = "Erro na preparação da declaração SQL: " . $conexao->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Adicionar Cirurgia</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 2.5em;
            margin: 0 0 20px;
            text-align: center;
        }

        h2 {
            font-size: 2em;
            color: #4CAF50;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
        }

        .form-group textarea {
            height: 100px;
        }

        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.2em;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .success-message, .error-message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <header>
        <h1>Adicionar Cirurgia</h1>
        <nav>
            <a href="prontuarios.php">Prontuários</a>
            <a href="estoque.php">Estoque</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <div class="container">
        <h2><?php echo htmlspecialchars($nome_pet); ?></h2> <!-- Nome do animal em destaque -->

        <?php if ($mensagem_sucesso) : ?>
            <div class="success-message"><?php echo htmlspecialchars($mensagem_sucesso); ?></div>
        <?php endif; ?>
        <?php if ($mensagem_erro) : ?>
            <div class="error-message"><?php echo htmlspecialchars($mensagem_erro); ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="hidden" name="id_pet" value="<?php echo $id_pet; ?>">
            <div class="form-group">
                <label for="descricao">Descrição da Cirurgia:</label>
                <textarea id="descricao" name="descricao" required></textarea>
            </div>
            <div class="form-group">
                <label for="data">Data da Cirurgia:</label>
                <input type="date" id="data" name="data" required>
            </div>
            <div class="form-group">
                <label for="tipo">Tipo de Cirurgia:</label>
                <input type="text" id="tipo" name="tipo" required>
            </div>
            <div class="form-group">
                <label for="observacoes">Observações:</label>
                <textarea id="observacoes" name="observacoes"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn">Adicionar Cirurgia</button>
            </div>
        </form>
    </div>
</body>
</html>
