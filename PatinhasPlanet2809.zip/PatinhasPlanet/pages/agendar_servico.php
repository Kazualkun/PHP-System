<?php
session_start();
include_once '../config/config.php';

if (!isset($_SESSION['email'])) {
    header('Location: ../index.php');
    exit();
}

$nome = $_SESSION['nome'];
$id_cliente = isset($_SESSION['id_usuario']) ? $_SESSION['id_usuario'] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['pet']) && isset($_POST['data']) && isset($_POST['hora']) && isset($_POST['servico'])) {
        $id_pet = $_POST['pet'];
        $data = $_POST['data'];
        $hora = $_POST['hora'];
        $servico = $_POST['servico'];

        // Verificar se a data e hora são válidas
        if (DateTime::createFromFormat('Y-m-d', $data) && DateTime::createFromFormat('H:i', $hora)) {
            // Verificar se o horário está disponível
            $stmt = $conexao->prepare("SELECT * FROM agendamentos WHERE data = ? AND hora = ?");
            $stmt->bind_param("ss", $data, $hora);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $mensagem = "Horário indisponível. Por favor, escolha outro horário.";
            } else {
                // Inserir novo agendamento com tipo de serviço correto
                $stmt = $conexao->prepare("INSERT INTO agendamentos (id_pet, data, hora, tipo_servico, status) VALUES (?, ?, ?, ?, 'agendado')");
                $stmt->bind_param("isss", $id_pet, $data, $hora, $servico);

                if ($stmt->execute()) {
                    $mensagem = "Serviço agendado com sucesso.";
                } else {
                    $mensagem = "Erro ao agendar o serviço. Tente novamente.";
                }
                $stmt->close();
            }
        } else {
            $mensagem = "Data ou hora inválida. Verifique os valores inseridos.";
        }
    } else {
        $mensagem = "Por favor, preencha todos os campos.";
    }
}

// Buscar os pets do usuário
$stmt = $conexao->prepare("SELECT * FROM pets WHERE id_usuario = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
$pets = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar Serviço</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles/home.css" />
</head>
<body>
    <header class="bg-orange">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <a class="navbar-brand" href="../pages/home.php">
                    <img src="../assets/img/logo.png" alt="logo" class="img-fluid">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="../pages/home.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="../pages/cadastrar_pet.php">Meus Pets</a></li>
                        <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="container mt-5">
            <h1>Agendar Serviço</h1>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="mb-3">
                    <label for="pet" class="form-label">Selecione o Pet:</label>
                    <select class="form-select" name="pet" id="pet" required>
                        <option value="" disabled selected>Selecione um pet</option>
                        <?php foreach ($pets as $pet) : ?>
                            <option value="<?php echo htmlspecialchars($pet['id_pet']); ?>"><?php echo htmlspecialchars($pet['nome_pet']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="data" class="form-label">Data:</label>
                    <input type="date" class="form-control" id="data" name="data" required>
                </div>
                <div class="mb-3">
                    <label for="hora" class="form-label">Hora:</label>
                    <input type="time" class="form-control" id="hora" name="hora" required>
                </div>
                <div class="mb-3">
                    <label for="servico" class="form-label">Tipo de Serviço:</label>
                    <select class="form-select" name="servico" id="servico" required>
                        <option value="" disabled selected>Selecione o tipo de serviço</option>
                        <option value="banho">Banho</option>
                        <option value="tosa">Tosa</option>
                        <option value="banho_e_tosa">Banho e Tosa</option>
                        <option value="consulta">Consulta Veterinária</option>
                        <option value="cirurgia">Cirurgia</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Agendar Serviço</button>
            </form>
            <?php if (isset($mensagem)) : ?>
                <div class="alert alert-success mt-3" role="alert">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <footer class="bg-orange text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Links Úteis</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Serviços</a></li>
                        <li><a href="#">Agendamentos</a></li>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Contato</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contato</h5>
                    <p>Endereço: Rua dos Animais, 123</p>
                    <p>Telefone: (XX) XXXX-XXXX</p>
                    <p>Email: contato@patinhasplanet.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Redes Sociais</h5>
                    <ul class="list-unstyled">
                        <li><a href="#"><i class="fab fa-facebook-f"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>&copy; <?php echo date("Y"); ?> Patinhas Planet. Todos os direitos reservados.</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
