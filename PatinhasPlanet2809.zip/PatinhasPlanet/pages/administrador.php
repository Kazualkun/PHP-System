<?php
session_start();


// Verifica se o usuário está autenticado e é um administrador
if (!isset($_SESSION['tipo_usuario']) || $_SESSION['tipo_usuario'] !== 'administrador') {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="../assets/styles/administrador.css">
</head>

<body>

    <nav class="navbar">
        <a href="administrador.php">Página Inicial</a>
        <a href="gerenciar_usuarios.php">Gerenciar Usuários</a>
        <a href="estoque.php">Estoque</a>
        <a class="nav-link btn-logout" href="../config/logout.php">Logout</a>
    </nav>

    <div class="container">
        <div class="card">
            <div class="section">
                <h2>Bem-vindo ao Painel Administrativo</h2>
                <p>Aqui você pode gerenciar todas as funções administrativas do sistema.</p>
            </div>

            <div class="section">
                <h3>Agendamentos Recentes</h3>
                <p>Visualize e gerencie os agendamentos mais recentes aqui.</p>
                <!-- Conteúdo para agendamentos recentes -->
            </div>

            <div class="section">
                <h3>Notificações</h3>
                <p>Acompanhe as notificações importantes e atualizações do sistema.</p>
                <!-- Conteúdo para notificações -->
            </div>
        </div>
    </div>

</body>

</html>