<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Alta</title>
    <link rel="stylesheet" href="../css/styles.css"> <!-- Link para o seu CSS -->
    <style>
        /* Estilos semelhantes aos da página histórico */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 20px;
        }

        header {
            background-color: #fff;
            padding: 20px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>

<body>
    <div class="container">

        <?php
        // Incluir arquivo de configuração do banco de dados
        include('../config/config.php');
        session_start();

        // Verificar se o veterinário está logado
        if (!isset($_SESSION['id_usuario'])) {
            header("Location: login.php");
            exit();
        }

        // Recebe o ID do pet via GET
        $id_pet = $_GET['id_pet'] ?? null;
        $id_veterinario = $_SESSION['id_usuario']; // Obtém o ID do veterinário logado

        if ($id_pet) {
            // Consulta para obter o nome do pet
            $sql_pet = "SELECT nome_pet FROM pets WHERE id_pet = ?";
            $stmt_pet = $conexao->prepare($sql_pet);
            $stmt_pet->bind_param("i", $id_pet);
            $stmt_pet->execute();
            $result_pet = $stmt_pet->get_result();

            if ($result_pet->num_rows > 0) {
                $pet = $result_pet->fetch_assoc();
                $nome_pet = htmlspecialchars($pet['nome_pet']);

                // Cabeçalho com navegação
                echo '<header>
                    <h1>Adicionar Alta para ' . $nome_pet . '</h1>
                    <nav>
                        <a href="prontuarios.php?id_pet=' . htmlspecialchars($id_pet) . '">Prontuários</a>
                        <a href="estoque.php">Estoque</a>
                        <a href="historico.php">Histórico</a>
                        <a href="logout.php">Logout</a>
                    </nav>
                  </header>';

                // Verifica se o formulário foi enviado
                if ($_SERVER["REQUEST_METHOD"] === "POST") {
                    $descricao = $_POST['descricao'] ?? '';
                    $data = $_POST['data'] ?? date('Y-m-d H:i:s');

                    // Valida os dados
                    if ($descricao) {
                        // Insere a alta no banco de dados
                        $sql = "INSERT INTO altas (id_pet, id_veterinario, descricao, data) VALUES (?, ?, ?, ?)";
                        $stmt = $conexao->prepare($sql);
                        $stmt->bind_param("iiss", $id_pet, $id_veterinario, $descricao, $data);
                        
                        if ($stmt->execute()) {
                            echo "<p>Alta adicionada com sucesso!</p>";
                        } else {
                            echo "<p>Erro ao adicionar alta: " . htmlspecialchars($stmt->error) . "</p>";
                        }
                    } else {
                        echo "<p>Por favor, preencha todos os campos.</p>";
                    }
                }
            } else {
                echo "<p>Pet não encontrado.</p>";
            }
        ?>

            <form id="altaForm" action="adicionar_altas.php?id_pet=<?php echo htmlspecialchars($id_pet); ?>" method="post">
                <div class="form-group">
                    <label>Descrição:</label>
                    <input type="text" name="descricao" required>
                </div>

                <div class="form-group">
                    <label>Data:</label>
                    <input type="datetime-local" name="data" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn">Adicionar Alta</button>
                </div>
            </form>

            <?php
            echo '</div>'; // Fecha o container
        } else {
            echo "<p>ID do pet não fornecido.</p>";
        }
        ?>
    </div>
</body>

</html>
