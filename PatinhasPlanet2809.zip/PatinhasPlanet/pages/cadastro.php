<?php
//procura o submit do botão cadastrar
if (isset($_POST['submit'])) {
    // Inclui o arquivo de configuração do banco de dados
    include_once('../config/config.php'); // Ajuste o caminho de acordo com a localização correta do arquivo

    // Verifica se a conexão foi estabelecida
    if (!$conexao) {
        die("Erro de conexão: " . mysqli_connect_error());
    }

    // Escape dos dados para evitar SQL Injection
    $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
    $email = mysqli_real_escape_string($conexao, $_POST['email']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
    $tipo = 'cliente'; // Definindo o tipo como 'cliente' por padrão

    // Insere os dados buscados acima no banco de dados
    $query = "INSERT INTO Usuarios (nome, email, senha, tipo) VALUES ('$nome', '$email', '$senha', '$tipo')";
    $result = mysqli_query($conexao, $query);

    // Finaliza o cadastro e mostra o resultado
    if ($result) {
        echo "Cadastro realizado com sucesso!";
    } else {
        echo "Erro ao cadastrar usuário: " . mysqli_error($conexao);
    }

    // Fecha a conexão
    mysqli_close($conexao);
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        body {
    background-color: #f0f0f0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.container {
    background: #E45125;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 500px;
    width: 100%;
}

.logo img {
    display: block;
    margin: 0 auto 1rem;
    max-width: 350px;
}

form {
    margin-bottom: 1rem;
}

label {
    font-weight: bold;
}

input {
    width: 100%;
    margin-bottom: 1rem;
    padding: 0.5rem;
    border: 1px solid #ced4da;
    border-radius: 4px;
}

button {
    width: 100%;
    padding: 0.75rem;
    margin-bottom: 0.5rem;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
}

button a {
    color: white;
    text-decoration: none;
}

p {
    text-align: center;
}

p a {
    color: #000000;
    text-decoration: underline;
}

    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="assets/img/patinhasLogo.png" alt="logo" class="img-fluid">
        </div>
        <form action="cadastro.php" method="POST">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" required>
            <label for="nome">Nome de Usuário</label>
            <input type="text" id="nome" name="nome" required>
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required>
            <input type="hidden" name="user_type" value="cliente"> <!-- Campo oculto para tipo de usuário -->
            <button type="submit" name="submit">Cadastrar</button>
        </form>
        <p><a href="../pages/login.php">Já tem cadastro? Faça login</a></p>
    </div>
</body>

</html>
