<?php
session_start();
require_once('../config/config.php');

// Verificar se existe uma mensagem de sucesso ou erro
if (isset($_SESSION['message'])) {
    echo "<div class='message {$_SESSION['message_type']}'>{$_SESSION['message']}</div>";
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Buscar todos os usuários
$query = "SELECT id_usuario, nome, email, tipo FROM usuarios";
$result = $conexao->query($query);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários</title>
    <link rel="stylesheet" href="">
    <style>
        /* Estilos Gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        main {
            width: 80%;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Títulos e Botões */
        h1 {
            margin-bottom: 20px;
            color: #4CAF50;
        }

        .btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-edit {
            background-color: #2196F3;
            padding: 5px 10px;
            color: #fff;
            text-decoration: none;
            border-radius: 3px;
            margin-right: 5px;
        }

        .btn-edit:hover {
            background-color: #1e88e5;
        }

        .btn-delete {
            background-color: #f44336;
            padding: 5px 10px;
            color: #fff;
            text-decoration: none;
            border-radius: 3px;
        }

        .btn-delete:hover {
            background-color: #e53935;
        }

        /* Tabela de Usuários */
        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .user-table th,
        .user-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .user-table th {
            background-color: #f2f2f2;
            color: #333;
        }

        .user-table tr:hover {
            background-color: #f1f1f1;
        }

        /* Mensagens */
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .message.success {
            background-color: #4CAF50;
            color: #fff;
        }

        .message.error {
            background-color: #f44336;
            color: #fff;
        }
    </style>
</head>

<header>
    <nav class="navbar">
        <a href="../pages/administrador.php">Administração</a>
        <a href="../pages/estoque.php">Estoque</a>
        <a href="../config/logout.php">Logout</a>
    </nav>
</header>

<body>
    <main>
        <h1>Gerenciar Usuários</h1>
        <a class="btn" href="criar_editar_usuario.php">Adicionar Novo Usuário</a>
        <table class="user-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id_usuario']; ?></td>
                        <td><?php echo $row['nome']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo ucfirst($row['tipo']); ?></td>
                        <td>
                            <a class="btn-edit" href="criar_editar_usuario.php?id=<?php echo $row['id_usuario']; ?>">Editar</a>
                            <a class="btn-delete" href="excluir_usuario.php?id=<?php echo $row['id_usuario']; ?>" onclick="return confirm('Tem certeza que deseja excluir este usuário?');">Excluir</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</body>

</html>

<?php
$conexao->close();
?>