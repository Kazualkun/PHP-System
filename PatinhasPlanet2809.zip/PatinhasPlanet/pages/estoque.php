<?php
session_start();
require_once('../config/config.php');

// Verificar se existe uma mensagem de sucesso ou erro
if (isset($_SESSION['message'])) {
    echo "<div class='message {$_SESSION['message_type']}'>{$_SESSION['message']}</div>";
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}

// Buscar todos os produtos do estoque
$query = "SELECT id_produto, nome_produto, tipo_produto, quantidade, fornecedor, data_validade, preco FROM estoque";
$result = $conexao->query($query);


?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Estoque</title>
    <link rel="stylesheet" href="">
    <style>
        /* Estilos Gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        main {
            width: 90%;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Títulos e Botões */
        h1 {
            margin-bottom: 20px;
            color: #4CAF50;
        }

        .btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-edit, .btn-delete, .btn-filter {
            padding: 5px 10px;
            color: #fff;
            text-decoration: none;
            border-radius: 3px;
            margin-right: 5px;
        }

        .btn-edit {
            background-color: #2196F3;
        }

        .btn-edit:hover {
            background-color: #1e88e5;
        }

        .btn-delete {
            background-color: #f44336;
        }

        .btn-delete:hover {
            background-color: #e53935;
        }

        .btn-filter {
            background-color: #FF9800;
        }

        .btn-filter:hover {
            background-color: #FB8C00;
        }

        /* Tabela de Estoque */
        .stock-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .stock-table th, .stock-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .stock-table th {
            background-color: #f2f2f2;
            color: #333;
        }

        .stock-table tr:hover {
            background-color: #f1f1f1;
        }

        /* Mensagens */
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .message.success {
            background-color: #4CAF50;
            color: #fff;
        }

        .message.error {
            background-color: #f44336;
            color: #fff;
        }

    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="../assets/images/patinhasLogo.png" alt="logo" class="img-fluid" width="150px" height="150px">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="../pages/home.php">Home</a></li>
                        <li class="nav-item">
                            <a class="nav-link btn-logout" href="../config/logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <main>
        <h1>Gerenciar Estoque</h1>
        <a class="btn" href="adicionar_produto.php">Adicionar Novo Produto</a>
        <a class="btn-filter" href="filtrar_produto.php">Filtrar Produtos</a>
        <table class="stock-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Tipo</th>
                    <th>Quantidade</th>
                    <th>Fornecedor</th>
                    <th>Data de Validade</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id_produto']; ?></td>
                        <td><?php echo $row['nome_produto']; ?></td>
                        <td><?php echo ucfirst($row['tipo_produto']); ?></td>
                        <td><?php echo $row['quantidade']; ?></td>
                        <td><?php echo $row['fornecedor']; ?></td>
                        <td><?php echo $row['data_validade'] ? date('d/m/Y', strtotime($row['data_validade'])) : 'N/A'; ?></td>
                        <td>R$ <?php echo number_format($row['preco'], 2, ',', '.'); ?></td>
                        <td>
                            <a class="btn-edit" href="editar_produto.php?id=<?php echo $row['id_produto']; ?>">Editar</a>
                            <a class="btn-delete" href="excluir_produto.php?id=<?php echo $row['id_produto']; ?>" onclick="return confirm('Tem certeza que deseja excluir este produto?');">Excluir</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</body>
</html>

<?php
$conexao->close();
?>
