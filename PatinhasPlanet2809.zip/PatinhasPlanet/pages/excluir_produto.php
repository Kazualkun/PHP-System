<?php
session_start();
require_once('../config/config.php');

if (isset($_GET['id'])) {
    $id_produto = $_GET['id'];

    $query = "DELETE FROM estoque WHERE id_produto = ?";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("i", $id_produto);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Produto excluído com sucesso!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Erro ao excluir produto: " . $stmt->error;
        $_SESSION['message_type'] = "error";
    }

    $stmt->close();
    $conexao->close();
    header("Location: gerenciar_estoque.php");
    exit();
} else {
    header("Location: gerenciar_estoque.php");
    exit();
}
?>
