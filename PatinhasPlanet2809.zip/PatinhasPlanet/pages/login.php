<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../assets/styles/login.css">
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="..assets/images/patinhasLogo.png" alt="logo" class="img-fluid">
        </div>
        
        <?php
        if (isset($_SESSION['login_error'])) {
            echo "<p style='color:red;'>" . $_SESSION['login_error'] . "</p>";
            unset($_SESSION['login_error']);
        }
        ?>

        <form action="../config/check.php" method="POST">
            <label for="nome">E-mail ou Nome de Usuário</label>
            <input type="text" id="nome" name="nome" required>
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required>
            <button type="submit" name="submit">Login</button>
        </form>
        <p><a href="../pages/esqueci_senha.php">Esqueceu sua senha? Recupere aqui!</a></p>
        <p>Não tem cadastro? Faça aqui</p>
        <button><a href="../pages/cadastro.php">Cadastrar</a></button>
    </div>
</body>
</html>
