<?php
// Incluir arquivo de configuração do banco de dados
include('../config/config.php');
session_start();

// Verificar se o veterinário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Recebe o ID do pet via GET
$id_pet = $_GET['id_pet'] ?? null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $id_pet) {
    // Captura os dados do formulário
    $nome_pet = $_POST['nome_pet'] ?? '';
    $especie = $_POST['especie'] ?? '';
    $raca = $_POST['raca'] ?? '';
    $idade = $_POST['idade'] ?? '';
    $peso = $_POST['peso'] ?? '';
    $observacoes = $_POST['observacoes'] ?? '';

    // Atualiza os dados no banco
    $sql_update = "UPDATE pets SET nome_pet = ?, especie = ?, raca = ?, idade = ?, peso = ?, observacoes = ? WHERE id_pet = ?";
    $stmt_update = $conexao->prepare($sql_update);
    $stmt_update->bind_param("sssdssi", $nome_pet, $especie, $raca, $idade, $peso, $observacoes, $id_pet);

    if ($stmt_update->execute()) {
        // Redireciona para a página de histórico com mensagem de sucesso
        header("Location: historico.php?id_pet=$id_pet&msg=salvo");
        exit();
    } else {
        $error_message = "Erro ao atualizar os dados: " . $stmt_update->error;
    }
}

// Consulta para buscar dados do pet
if ($id_pet) {
    $sql_pet = "SELECT nome_pet, especie, raca, idade, peso, observacoes FROM pets WHERE id_pet = ?";
    $stmt_pet = $conexao->prepare($sql_pet);
    $stmt_pet->bind_param("i", $id_pet);
    $stmt_pet->execute();
    $resultado_pet = $stmt_pet->get_result()->fetch_assoc();
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Editar Dados do Pet</title>
</head>
<style>
    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #f9f9f9;
    }

    .form-group {
        margin-bottom: 15px;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    input[type="text"],
    input[type="number"],
    textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .btn {
        display: inline-block;
        background-color: #007BFF;
        color: #fff;
        padding: 10px 15px;
        border-radius: 4px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .btn:hover {
        background-color: #0056b3;
    }

    .error-message {
        color: red;
        margin-bottom: 20px;
    }
</style>

<body>
    <header>
        <h1>Editar Dados do Pet</h1>
        <nav>
            <a href="prontuarios.php?id_pet=<?php echo htmlspecialchars($id_pet); ?>">Prontuários</a>
            <a href="estoque.php">Estoque</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <div class="container">
        <?php if (isset($error_message)) : ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <?php if ($resultado_pet) : ?>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="nome_pet">Nome do Pet:</label>
                    <input type="text" id="nome_pet" name="nome_pet" value="<?php echo htmlspecialchars($resultado_pet['nome_pet']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="especie">Espécie:</label>
                    <input type="text" id="especie" name="especie" value="<?php echo htmlspecialchars($resultado_pet['especie']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="raca">Raça:</label>
                    <input type="text" id="raca" name="raca" value="<?php echo htmlspecialchars($resultado_pet['raca']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="idade">Idade (anos):</label>
                    <input type="number" id="idade" name="idade" value="<?php echo htmlspecialchars($resultado_pet['idade']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="peso">Peso (kg):</label>
                    <input type="number" step="0.1" id="peso" name="peso" value="<?php echo htmlspecialchars($resultado_pet['peso']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="observacoes">Observações:</label>
                    <textarea id="observacoes" name="observacoes" required><?php echo htmlspecialchars($resultado_pet['observacoes']); ?></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Salvar</button>
                </div>
            </form>
        <?php else : ?>
            <p>Pet não encontrado.</p>
        <?php endif; ?>
    </div>
</body>

</html>