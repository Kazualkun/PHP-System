<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico do Pet</title>
    <link rel="stylesheet" href="../css/styles.css"> <!-- Link para o seu CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 20px;
        }

        header {
            background-color: #fff;
            padding: 20px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h1 {
            margin: 0;
            font-size: 24px;
        }

        nav {
            margin-top: 15px;
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 22px;
            margin-bottom: 10px;
        }

        h3 {
            font-size: 20px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 5px;
            margin-top: 20px;
        }

        .form-group {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group input:disabled {
            background-color: #e9ecef;
        }

        .prescricao,
        .cirurgia,
        .alta,
        .evolucao,
        .exame {
            margin: 10px 0;
            padding: 10px;
            background-color: #f0f8ff;
            border-left: 4px solid #007BFF;
            border-radius: 4px;
        }

        .prescricao p,
        .cirurgia p,
        .alta p,
        .evolucao p,
        .exame p {
            margin: 5px 0;
        }

        footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #777;
        }

        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php
        // Incluir arquivo de configuração do banco de dados
        include('../config/config.php');
        session_start();

        // Verificar se o veterinário está logado
        if (!isset($_SESSION['id_usuario'])) {
            header("Location: login.php");
            exit();
        }

        // Recebe o ID do pet via GET ou POST
        $id_pet = $_GET['id_pet'] ?? null;

        if ($id_pet) {
            // Cabeçalho com navegação
            echo '<header>
            <h1>Histórico do Pet</h1>
            <nav>
                <a href="prontuarios.php?id_pet=' . htmlspecialchars($id_pet) . '">Prontuários</a>
                <a href="estoque.php">Estoque</a>
                <a href="logout.php">Logout</a>
            </nav>
          </header>';

            // Consulta para buscar dados do pet
            $sql_pet = "SELECT nome_pet, especie, raca, idade, peso, observacoes FROM pets WHERE id_pet = ?";
            $stmt_pet = $conexao->prepare($sql_pet);
            $stmt_pet->bind_param("i", $id_pet);
            $stmt_pet->execute();
            $resultado_pet = $stmt_pet->get_result()->fetch_assoc();

            if ($resultado_pet) {
                // Estrutura do container
                echo '<div class="container">';

                // Dados do pet
                echo "<h2>Pet: " . htmlspecialchars($resultado_pet['nome_pet']) . "</h2>";
                echo '<div class="form-group">
                <label>Espécie:</label>
                <input type="text" value="' . htmlspecialchars($resultado_pet['especie']) . '" disabled>
                <label>Raça:</label>
                <input type="text" value="' . htmlspecialchars($resultado_pet['raca'] ?? 'N/A') . '" disabled>
                <label>Idade:</label>
                <input type="text" value="' . htmlspecialchars($resultado_pet['idade'] ?? 'N/A') . ' anos" disabled>
                <label>Peso:</label>
                <input type="text" value="' . htmlspecialchars($resultado_pet['peso'] ?? 'N/A') . ' kg" disabled>
              </div>';

                echo "<h3>Observações:</h3>";
                echo '<textarea disabled>' . htmlspecialchars($resultado_pet['observacoes'] ?? 'Nenhuma') . '</textarea>';

                // Botão "Editar Pet"
                echo '<div class="form-group">
                <a href="editar_dados_pet.php?id_pet=' . htmlspecialchars($id_pet) . '" class="btn">Editar Pet</a>
              </div>';

                // Seções de Histórico
                $sections = [
                    ['title' => 'Cirurgias', 'sql' => "SELECT c.data AS data, c.descricao FROM cirurgias c WHERE c.id_pet = ?"],
                    ['title' => 'Altas', 'sql' => "SELECT a.data AS data, a.descricao FROM altas a WHERE a.id_pet = ?"],
                    ['title' => 'Prescrições', 'sql' => "SELECT p.medicamento, p.dosagem, p.frequencia, p.duracao, pr.data AS data FROM prescricoes p JOIN prontuarios pr ON p.id_prontuario = pr.id_prontuario WHERE pr.id_pet = ?"],
                    ['title' => 'Exames', 'sql' => "SELECT e.tipo_exame, e.resultado, e.data AS data FROM exames e JOIN prontuarios pr ON e.id_prontuario = pr.id_prontuario WHERE pr.id_pet = ?"],
                    ['title' => 'Evoluções', 'sql' => "SELECT e.data, e.descricao FROM evolucoes e WHERE e.id_pet = ?"]
                ];

                foreach ($sections as $section) {
                    echo "<h3>" . htmlspecialchars($section['title']) . "</h3>";
                    $stmt_section = $conexao->prepare($section['sql']);
                    $stmt_section->bind_param("i", $id_pet);
                    $stmt_section->execute();
                    $resultado_section = $stmt_section->get_result();

                    if ($resultado_section->num_rows > 0) {
                        while ($row = $resultado_section->fetch_assoc()) {
                            echo '<div class="' . strtolower($section['title']) . '">
                            <p><strong>Data:</strong> ' . date('d/m/Y H:i', strtotime($row['data'])) . '</p>
                            <p><strong>Descrição:</strong> ' . htmlspecialchars($row['descricao']) . '</p>
                          </div>';
                        }
                    } else {
                        echo "<p>Sem registros para esta seção.</p>";
                    }
                    
                    // Botão para adicionar histórico
                    echo '<div class="form-group">
                    <a href="adicionar_' . strtolower($section['title']) . '.php?id_pet=' . htmlspecialchars($id_pet) . '&nome_pet=' . urlencode($resultado_pet['nome_pet']) . '" class="btn">Adicionar ' . htmlspecialchars($section['title']) . '</a>
                </div>';
                }

                echo '</div>'; // Fecha o container
            } else {
                echo "<p>Pet não encontrado.</p>";
            }
        } else {
            echo "<p>ID do pet não fornecido.</p>";
        }
        ?>

    </div>
</body>

</html>