<?php
session_start();
require_once('../config/config.php');

// Recebe os dados do formulário
$id_usuario = isset($_POST['id_usuario']) ? intval($_POST['id_usuario']) : null;
$nome = $_POST['nome'];
$email = $_POST['email'];
$tipo_usuario = $_POST['tipo_usuario'];
$senha = isset($_POST['senha']) && !empty($_POST['senha']) ? password_hash($_POST['senha'], PASSWORD_DEFAULT) : null;

// Verifica se estamos editando ou criando um novo usuário
if ($id_usuario) {
    // Se uma nova senha foi fornecida, atualize-a; caso contrário, mantenha a senha atual
    if ($senha) {
        $query = "UPDATE usuarios SET nome=?, email=?, tipo_usuario=?, senha=? WHERE id_usuario=?";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param('sssii', $nome, $email, $tipo_usuario, $senha, $id_usuario);
    } else {
        $query = "UPDATE usuarios SET nome=?, email=?, tipo_usuario=? WHERE id_usuario=?";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param('sssi', $nome, $email, $tipo_usuario, $id_usuario);
    }
} else {
    // Criar um novo usuário (neste caso, a senha é obrigatória)
    if ($senha) {
        $query = "INSERT INTO usuarios (nome, email, tipo_usuario, senha) VALUES (?, ?, ?, ?)";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param('ssss', $nome, $email, $tipo_usuario, $senha);
    } else {
        $_SESSION['message'] = 'A senha é obrigatória ao criar um novo usuário.';
        $_SESSION['message_type'] = 'error';
        header('Location: ../pages/gerenciar_usuarios.php');
        exit();
    }
}

// Executa a query
if ($stmt->execute()) {
    $_SESSION['message'] = 'Usuário salvo com sucesso!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Erro ao salvar o usuário. Tente novamente mais tarde.';
    $_SESSION['message_type'] = 'error';
}

$stmt->close();
$conexao->close();

header('Location: ../pages/gerenciar_usuarios.php');
exit();
