<?php
session_start();
require_once('../config/config.php');

if (isset($_GET['id'])) {
    $id_usuario = intval($_GET['id']);

    if ($id_usuario > 0) {
        // Prepara a exclusão
        $query = "DELETE FROM usuarios WHERE id_usuario = ?";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param("i", $id_usuario);

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Usuário excluído com sucesso.';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Erro ao excluir o usuário.';
            $_SESSION['message_type'] = 'error';
        }
    } else {
        $_SESSION['message'] = 'ID de usuário inválido.';
        $_SESSION['message_type'] = 'error';
    }
} else {
    $_SESSION['message'] = 'Nenhum ID de usuário foi fornecido.';
    $_SESSION['message_type'] = 'error';
}

header('Location: gerenciar_usuarios.php');
exit();
