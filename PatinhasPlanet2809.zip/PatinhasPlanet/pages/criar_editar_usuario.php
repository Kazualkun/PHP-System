<?php
session_start();
require_once('../config/config.php');

// Verificar se um ID foi passado para edição
$nome = '';
$email = '';
$tipo = '';
$crmv = '';
$id_usuario = isset($_GET['id']) ? $_GET['id'] : null;

// Se for edição, carregar os dados do usuário
if ($id_usuario) {
    $query = "SELECT * FROM usuarios WHERE id_usuario = ?";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param('i', $id_usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();
    
    // Preencher os campos com os dados do usuário
    if ($usuario) {
        $nome = $usuario['nome'];
        $email = $usuario['email'];
        $tipo = $usuario['tipo'];
        $crmv = $usuario['crmv'];
    }
}

// Se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $tipo = $_POST['tipo'];
    $crmv = isset($_POST['crmv']) ? trim($_POST['crmv']) : '';

    // Captura a senha digitada pelo usuário
    $senha = isset($_POST['senha']) ? trim($_POST['senha']) : '';

    if ($tipo === 'veterinario' && (empty($crmv) || strlen($crmv) !== 5)) {
        $_SESSION['message'] = 'O CRMV é obrigatório e deve ter 5 dígitos para veterinários.';
        $_SESSION['message_type'] = 'error';
    } else {
        if ($id_usuario) {
            // Atualizar usuário existente
            $query = "UPDATE usuarios SET nome = ?, email = ?, tipo = ?, senha = ? WHERE id_usuario = ?";
            $stmt = $conexao->prepare($query);
            $stmt->bind_param('ssssi', $nome, $email, $tipo, $senha, $id_usuario);
        } else {
            // Criar novo usuário
            $query = "INSERT INTO usuarios (nome, email, senha, tipo, crmv) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conexao->prepare($query);
            $stmt->bind_param('sssss', $nome, $email, $senha, $tipo, $crmv);
        }

        if ($stmt->execute()) {
            $_SESSION['message'] = 'Usuário salvo com sucesso!';
            $_SESSION['message_type'] = 'success';
            header('Location: gerenciar_usuarios.php');
            exit();
        } else {
            $_SESSION['message'] = 'Erro ao salvar o usuário.';
            $_SESSION['message_type'] = 'error';
        }
    }

    $stmt->close();
    header('Location: gerenciar_usuarios.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id_usuario ? 'Editar Usuário' : 'Criar Novo Usuário'; ?></title>
    <link rel="stylesheet" href="">
    <style>
        /* Estilos Gerais */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        main {
            width: 400px;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Títulos e Botões */
        h1 {
            margin-bottom: 20px;
            color: #4CAF50;
            text-align: center;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            text-align: center;
            border: none;
            border-radius: 5px;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-back {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #757575;
            color: #fff;
            text-align: center;
            border: none;
            border-radius: 5px;
            margin-top: 10px;
            text-decoration: none;
        }

        .btn-back:hover {
            background-color: #616161;
        }

        /* Formulário */
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input,
        .form-group select {
            width: calc(100% - 20px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #4CAF50;
            outline: none;
        }
    </style>
</head>

<script>
        function validateForm() {
            const tipo = document.getElementById('tipo').value;
            const crmvField = document.getElementById('crmv');
            const crmvValue = crmvField.value.trim();
            const errorElement = document.getElementById('crmv-error');

            if (tipo === 'veterinario' && crmvValue === '') {
                errorElement.textContent = 'CRMV é obrigatório para veterinários.';
                return false; // Impede o envio do formulário
            } else if (tipo === 'veterinario' && crmvValue.length !== 5) {
                errorElement.textContent = 'CRMV deve ter 5 dígitos.';
                return false;
            }

            errorElement.textContent = ''; // Limpa o erro se estiver tudo ok
            return true; // Permite o envio do formulário
        }

        function toggleCrmvField() {
            const tipo = document.getElementById('tipo').value;
            const crmvField = document.getElementById('crmv-group');

            if (tipo === 'veterinario') {
                crmvField.style.display = 'block';
            } else {
                crmvField.style.display = 'none';
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('tipo').addEventListener('change', toggleCrmvField);
            toggleCrmvField(); // Executa ao carregar a página para ajustar o campo de CRMV
        });
    </script>
</head>

<body>
    <main>
        <h1><?php echo $id_usuario ? 'Editar Usuário' : 'Criar Novo Usuário'; ?></h1>
        <form method="POST" action="criar_editar_usuario.php<?php echo $id_usuario ? '?id=' . $id_usuario : ''; ?>" onsubmit="return validateForm();">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" placeholder="Deixe em branco para manter a senha atual">
            </div>
            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <select id="tipo" name="tipo" required>
                    <option value="admin" <?php echo $tipo === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                    <option value="funcionario" <?php echo $tipo === 'funcionario' ? 'selected' : ''; ?>>Funcionário</option>
                    <option value="veterinario" <?php echo $tipo === 'veterinario' ? 'selected' : ''; ?>>Veterinario</option>
                    <option value="cliente" <?php echo $tipo === 'cliente' ? 'selected' : ''; ?>>Cliente</option>
                </select>
            </div>
            <div class="form-group" id="crmv-group" style="display: none;">
                <label for="crmv">CRMV:</label>
                <input type="text" id="crmv" name="crmv" maxlength="5" value="<?php echo isset($crmv) ? htmlspecialchars($crmv) : ''; ?>">
                <div class="error" id="crmv-error"></div>
            </div>
            <button type="submit" class="btn"><?php echo $id_usuario ? 'Atualizar Usuário' : 'Criar Usuário'; ?></button>
        </form>
        <a class="btn-back" href="gerenciar_usuarios.php">Voltar</a>
    </main>
</body>

</html>
<?php
$conexao->close();
?>