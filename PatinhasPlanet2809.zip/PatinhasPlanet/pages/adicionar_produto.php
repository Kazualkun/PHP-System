<?php
session_start();
require_once('../config/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome_produto = $_POST['nome_produto'];
    $tipo_produto = $_POST['tipo_produto'];
    $quantidade = $_POST['quantidade'];
    $fornecedor = $_POST['fornecedor'];
    $data_validade = $_POST['data_validade'];
    $preco = $_POST['preco'];

    $query = "INSERT INTO estoque (nome_produto, tipo_produto, quantidade, fornecedor, data_validade, preco) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("ssissd", $nome_produto, $tipo_produto, $quantidade, $fornecedor, $data_validade, $preco);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Produto adicionado com sucesso!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Erro ao adicionar produto: " . $stmt->error;
        $_SESSION['message_type'] = "error";
    }

    $stmt->close();
    $conexao->close();
    header("Location: gerenciar_estoque.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 20px;
            text-align: center;
        }

        input[type="text"], input[type="number"], input[type="date"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form method="POST" action="adicionar_produto.php">
        <h2>Adicionar Produto</h2>
        <input type="text" name="nome_produto" placeholder="Nome do Produto" required>
        <select name="tipo_produto" required>
            <option value="" disabled selected>Selecione o Tipo</option>
            <option value="medicamento">Medicamento</option>
            <option value="higiene">Higiene</option>
            <option value="outro">Outro</option>
        </select>
        <input type="number" name="quantidade" placeholder="Quantidade" required>
        <input type="text" name="fornecedor" placeholder="Fornecedor">
        <input type="date" name="data_validade" placeholder="Data de Validade">
        <input type="number" step="0.01" name="preco" placeholder="Preço">
        <button type="submit" class="btn">Adicionar Produto</button>
    </form>
</body>
</html>
