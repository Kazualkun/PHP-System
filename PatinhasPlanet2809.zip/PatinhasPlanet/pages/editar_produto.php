<?php
session_start();
require_once('../config/config.php');

if (isset($_GET['id'])) {
    $id_produto = $_GET['id'];

    // Buscar os dados do produto
    $query = "SELECT * FROM estoque WHERE id_produto = ?";
    $stmt = $conexao->prepare($query);
    $stmt->bind_param("i", $id_produto);
    $stmt->execute();
    $result = $stmt->get_result();
    $produto = $result->fetch_assoc();

    if (!$produto) {
        $_SESSION['message'] = "Produto não encontrado!";
        $_SESSION['message_type'] = "error";
        header("Location: gerenciar_estoque.php");
        exit();
    }

    // Atualizar os dados do produto
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nome_produto = $_POST['nome_produto'];
        $tipo_produto = $_POST['tipo_produto'];
        $quantidade = $_POST['quantidade'];
        $fornecedor = $_POST['fornecedor'];
        $data_validade = $_POST['data_validade'];
        $preco = $_POST['preco'];

        $query = "UPDATE estoque SET nome_produto = ?, tipo_produto = ?, quantidade = ?, fornecedor = ?, data_validade = ?, preco = ? WHERE id_produto = ?";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param("ssissdi", $nome_produto, $tipo_produto, $quantidade, $fornecedor, $data_validade, $preco, $id_produto);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Produto atualizado com sucesso!";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Erro ao atualizar produto: " . $stmt->error;
            $_SESSION['message_type'] = "error";
        }

        header("Location: gerenciar_estoque.php");
        exit();
    }

    $stmt->close();
    $conexao->close();
} else {
    header("Location: gerenciar_estoque.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 20px;
            text-align: center;
        }

        input[type="text"], input[type="number"], input[type="date"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<header>
<nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="../assets/images/patinhasLogo.png" alt="logo" class="img-fluid" width="150px" height="150px">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a href="../pages/estoque.php"></a></li>
                        <li class="nav-item">
                            <a class="nav-link btn-logout" href="../config/logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
</header>
<body>
    <form method="POST" action="editar_produto.php?id=<?php echo $produto['id_produto']; ?>">
        <h2>Editar Produto</h2>
        <input type="text" name="nome_produto" value="<?php echo $produto['nome_produto']; ?>" required>
        <select name="tipo_produto" required>
            <option value="medicamento" <?php echo $produto['tipo_produto'] == 'medicamento' ? 'selected' : ''; ?>>Medicamento</option>
            <option value="higiene" <?php echo $produto['tipo_produto'] == 'higiene' ? 'selected' : ''; ?>>Higiene</option>
            <option value="outro" <?php echo $produto['tipo_produto'] == 'outro' ? 'selected' : ''; ?>>Outro</option>
        </select>
        <input type="number" name="quantidade" value="<?php echo $produto['quantidade']; ?>" required>
        <input type="text" name="fornecedor" value="<?php echo $produto['fornecedor']; ?>">
        <input type="date" name="data_validade" value="<?php echo $produto['data_validade']; ?>">
        <input type="number" step="0.01" name="preco" value="<?php echo $produto['preco']; ?>">
        <button type="submit" class="btn">Atualizar Produto</button>
    </form>
</body>
</html>
