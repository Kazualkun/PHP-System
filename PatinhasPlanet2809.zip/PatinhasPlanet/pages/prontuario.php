<?php
// Incluir arquivo de configuração do banco de dados
include('../config/config.php');
session_start();

// Verificar se o veterinário está logado
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];

// Buscar nome do veterinário logado
$sql_vet = "SELECT nome FROM usuarios WHERE id_usuario = ?";
$stmt_vet = $conexao->prepare($sql_vet);
$stmt_vet->bind_param("i", $id_usuario);
$stmt_vet->execute();
$result_vet = $stmt_vet->get_result();
$veterinario = $result_vet->fetch_assoc();
$nome_veterinario = $veterinario['nome'] ?? 'Veterinário';

// Consultar todos os agendamentos, incluindo cancelados
$sql_agendamentos = "SELECT a.id_agendamento, a.data, a.hora, a.tipo_servico, p.id_pet, p.nome_pet, u.nome, a.status
                     FROM agendamentos a
                     INNER JOIN pets p ON a.id_pet = p.id_pet
                     INNER JOIN usuarios u ON p.id_usuario = u.id_usuario
                     WHERE a.status IN ('agendado', 'cancelado')
                     ORDER BY a.data, a.hora"; // Ordena por data e hora

$stmt_agendamentos = $conexao->prepare($sql_agendamentos);
$stmt_agendamentos->execute();
$result = $stmt_agendamentos->get_result();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home do Veterinário</title>
    <link rel="stylesheet" href="../assets/styles/prontuario.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo">
            <h1>Patinhas Planet</h1>
        </div>
        <ul class="nav-links">
            <li><a href="../pages/estoque.php">Estoque</a></li>
            <li><a class="nav-link btn-logout" href="../config/logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <h2>Bem-vindo, Dr(a). <?php echo htmlspecialchars($nome_veterinario); ?>!</h2>
        <section class="agendamentos">
            <h3>Agendamentos Agendados e Cancelados</h3>
            <ul class="lista-agendamentos">
                <?php
                if ($result->num_rows > 0) {
                    // Exibir número total de agendamentos encontrados
                    echo "<p>Total de agendamentos encontrados: " . $result->num_rows . "</p>";

                    while ($row = $result->fetch_assoc()) {
                        // Extrair data e hora corretamente
                        $data = date('d/m/Y', strtotime($row['data'])); // Exibe a data formatada
                        $horario = date('H:i', strtotime($row['hora'])); // Exibe o horário
                        
                        $id_agendamento = $row['id_agendamento'];
                        $id_pet = $row['id_pet']; // Adiciona o ID do pet
                        $status = ucfirst($row['status']); // Status com a primeira letra maiúscula

                        echo "<li>
                        <span>{$data} - {$horario} - {$row['nome_pet']} (Dono: {$row['nome']}) - {$status} - " . ucfirst($row['tipo_servico']) . "</span>
                        <form method='POST' action='prontuario.php' class='agendamento-actions'>
                            <input type='hidden' name='id_agendamento' value='{$id_agendamento}'>";

                        if ($status === 'Cancelado') {
                            echo "<button type='submit' name='acao' value='remarcar' class='btn-remarcar'>Remarcar</button>";
                        } else {
                            echo "<button type='submit' name='acao' value='cancelar' class='btn-cancelar'>Cancelar</button>";
                        }

                        echo "<button type='submit' name='acao' value='editar' class='btn-editar'>Editar</button>
                        <a href='historico.php?id_pet={$id_pet}' class='btn-historico'>Histórico</a>
                        </form>
                      </li>";
                    }
                } else {
                    echo "<li>Não há agendamentos agendados ou cancelados.</li>";
                }
                ?>
            </ul>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Patinhas Planet - Todos os direitos reservados.</p>
    </footer>
    <?php
    // Lidar com as ações de Cancelar, Remarcar e Editar
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['id_agendamento']) && isset($_POST['acao'])) {
            $id_agendamento = intval($_POST['id_agendamento']);
            $acao = $_POST['acao'];

            if ($acao === 'cancelar') {
                // Cancelar agendamento: Atualiza o status para 'cancelado'
                $sql_cancelar = "UPDATE agendamentos SET status = 'cancelado' WHERE id_agendamento = ?";
                $stmt_cancelar = $conexao->prepare($sql_cancelar);
                $stmt_cancelar->bind_param("i", $id_agendamento);

                if ($stmt_cancelar->execute()) {
                    echo "<p>Agendamento cancelado com sucesso.</p>";
                    header("Refresh:0"); // Atualiza a página para refletir a mudança
                } else {
                    echo "<p>Erro ao cancelar agendamento.</p>";
                }
            } elseif ($acao === 'remarcar') {
                // Alterar status de 'cancelado' para 'agendado'
                $sql_remarcar = "UPDATE agendamentos SET status = 'agendado' WHERE id_agendamento = ?";
                $stmt_remarcar = $conexao->prepare($sql_remarcar);
                $stmt_remarcar->bind_param("i", $id_agendamento);

                if ($stmt_remarcar->execute()) {
                    echo "<p>Agendamento remarcado com sucesso.</p>";
                    header("Refresh:0"); // Atualiza a página para refletir a mudança
                } else {
                    echo "<p>Erro ao remarcar agendamento.</p>";
                }
            } elseif ($acao === 'editar') {
                // Redireciona para a página de edição de agendamento
                header("Location: editar_agendamento.php?id_agendamento=" . $id_agendamento);
                exit();
            }
        }
    }
    ?>
</body>
</html>
