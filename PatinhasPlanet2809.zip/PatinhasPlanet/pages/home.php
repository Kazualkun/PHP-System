<?php
session_start();
include_once '../config/config.php';

// Função para atualizar agendamentos
function atualizarAgendamentos($conexao) {
    $query = "UPDATE agendamentos 
              SET status = 'concluido' 
              WHERE data < CURDATE() 
              AND status != 'concluido' 
              AND status != 'cancelado'";
    $conexao->query($query);
}

// Chamar a função de atualização
atualizarAgendamentos($conexao);

if (!isset($_SESSION['email'])) {
    header('Location: ../index.php');
    exit();
}

$nome = $_SESSION['nome'];
$id_cliente = isset($_SESSION['id_usuario']) ? $_SESSION['id_usuario'] : null;

// Consultar os agendamentos do cliente no banco de dados
$stmt = $conexao->prepare("SELECT a.*, p.nome_pet FROM agendamentos a JOIN pets p ON a.id_pet = p.id_pet WHERE p.id_usuario = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
$agendamentos = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles/home.css" />
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.14/index.global.min.js'></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'pt-br',
                events: '../config/fetch_events.php',
                dateClick: function(info) {
                    var dataSelecionada = info.dateStr;
                    // Exibir um modal ou formulário para adicionar um novo evento
                }
            });
            calendar.render();
        });
    </script>
</head>

<body>
    <header class="bg-orange">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="../assets/images/patinhasLogo.png" alt="logo" class="img-fluid" width="150px" height="150px">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="../pages/home.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="../pages/agendar_servico.php">Serviços</a></li>
                        <li class="nav-item"><a class="nav-link" href="../pages/agendamentos.php">Agendamentos</a></li>
                        <!-- Adicionando o botão de logout -->
                        <li class="nav-item">
                            <a class="nav-link btn-logout" href="../config/logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="container mt-5">
            <h1>Bem-vindo, <?php echo htmlspecialchars($nome); ?>!</h1>
            <section>
                <h2>Veja os seus Serviços agendados e as datas disponíveis no calendário abaixo</h2>
                <h2>Calendário</h2>
                <div id='calendar'></div>
            </section>

            <section class="my-5">
                <h2>Serviços Agendados</h2>
                <?php if (!empty($agendamentos)) : ?>
                    <ul class="list-group">
                        <?php foreach ($agendamentos as $agendamento) : ?>
                            <li class="list-group-item">
                                <strong>Pet:</strong> <?php echo htmlspecialchars($agendamento['nome_pet']); ?><br>
                                <strong>Data:</strong> <?php echo htmlspecialchars($agendamento['data']); ?><br>
                                <strong>Hora:</strong> <?php echo htmlspecialchars($agendamento['hora']); ?><br>
                                <strong>Serviço:</strong> 
                                <?php
                                    // Tratamento para exibir o nome correto do serviço
                                    $tipo_servico = $agendamento['tipo_servico'];
                                    if ($tipo_servico == 'banho_e_tosa') {
                                        echo 'Banho e Tosa';
                                    } else {
                                        echo htmlspecialchars($tipo_servico);
                                    }
                                ?>
                                <br>
                                <strong>Status:</strong> <?php echo htmlspecialchars($agendamento['status']); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p>Nenhum serviço agendado.</p>
                <?php endif; ?>
            </section>

            <section class="my-5">
                <h2>Agendar Serviço</h2>
                <a href="../pages/agendar_servico.php" class="btn btn-primary mt-3">Agendar Serviço</a>
            </section>

            <section class="my-5">
                <h2>Meus Pets</h2>
                <?php
                $stmt = $conexao->prepare("SELECT nome_pet FROM pets WHERE id_usuario = ?");
                $stmt->bind_param("i", $_SESSION['id_usuario']);
                $stmt->execute();
                $result = $stmt->get_result();
                $pets = $result->fetch_all(MYSQLI_ASSOC);
                $stmt->close();

                if (empty($pets)) {
                    echo "<p>Você não possui pets cadastrados.</p>";
                } else {
                    echo "<ul>";
                    foreach ($pets as $pet) {
                        echo "<li>" . htmlspecialchars($pet['nome_pet']) . "</li>";
                    }
                    echo "</ul>";
                }
                ?>
                <a href="../pages/cadastrar_pet.php" class="btn btn-primary mt-3">Cadastrar Pets</a>
            </section>
        </section>
    </main>

    <footer class="bg-orange text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Links Úteis</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Serviços</a></li>
                        <li><a href="#">Agendamentos</a></li>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Contato</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contato</h5>
                    <p>Endereço: Rua dos Animais, 123</p>
                    <p>Telefone: (XX) XXXX-XXXX</p>
                    <p>Email: contato@patinhasplanet.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Redes Sociais</h5>
                    <ul class="list-unstyled">
                        <li><a href="#"><i class="fab fa-facebook-f"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>&copy; <?php echo date("Y"); ?> Patinhas Planet. Todos os direitos reservados.</p>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>
