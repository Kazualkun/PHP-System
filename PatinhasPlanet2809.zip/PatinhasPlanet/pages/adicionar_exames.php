<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Exame</title>
    <link rel="stylesheet" href="../css/styles.css"> <!-- Link para o seu CSS -->
    <style>
        /* Estilo básico */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        h1 {
            color: #333;
            margin-bottom: 10px;
        }

        nav {
            margin-top: 10px;
        }

        nav a {
            margin: 0 15px;
            text-decoration: none;
            color: #007BFF;
        }

        nav a:hover {
            text-decoration: underline;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button.btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }

        button.btn:hover {
            background-color: #0056b3;
        }

        .success-message {
            color: #28a745;
            font-weight: bold;
            margin-top: 15px;
        }

        .error-message {
            color: #dc3545;
            font-weight: bold;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php
        // Incluir arquivo de configuração do banco de dados
        include('../config/config.php');
        session_start();

        // Verificar se o veterinário está logado
        if (!isset($_SESSION['id_usuario'])) {
            header("Location: login.php");
            exit();
        }

        // Recebe o ID do pet via GET
        $id_pet = $_GET['id_pet'] ?? null;

        if ($id_pet) {
            // Consultar o nome do pet
            $sql_pet = "SELECT nome_pet FROM pets WHERE id_pet = ?";
            $stmt_pet = $conexao->prepare($sql_pet);
            $stmt_pet->bind_param("i", $id_pet);
            $stmt_pet->execute();
            $resultado_pet = $stmt_pet->get_result();
            $pet = $resultado_pet->fetch_assoc();

            // Cabeçalho com navegação
            echo '<header>
                <h1>Adicionar Exame</h1>
                <h2>Pet: ' . htmlspecialchars($pet['nome_pet']) . '</h2>
                <nav>
                    <a href="prontuarios.php?id_pet=' . htmlspecialchars($id_pet) . '">Prontuários</a>
                    <a href="estoque.php">Estoque</a>
                    <a href="logout.php">Logout</a>
                </nav>
              </header>';

            // Formulário para adicionar exame
            echo '<h2>Adicionar Exame para o Pet</h2>';
            echo '<form action="" method="POST">
                <div class="form-group">
                    <label>Tipo de Exame:</label>
                    <input type="text" name="tipo_exame" required>
                </div>
                <div class="form-group">
                    <label>Resultado:</label>
                    <textarea name="resultado" required></textarea>
                </div>
                <div class="form-group">
                    <label>Data:</label>
                    <input type="date" name="data" required>
                </div>
                <button type="submit" class="btn">Adicionar Exame</button>
            </form>';

            // Processar o formulário ao ser enviado
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $tipo_exame = $_POST['tipo_exame'];
                $resultado = $_POST['resultado'];
                $data = $_POST['data'];

                // Inserir exame no banco de dados
                $sql = "INSERT INTO exames (tipo_exame, resultado, data, id_prontuario) 
                        VALUES (?, ?, ?, (SELECT id_prontuario FROM prontuarios WHERE id_pet = ? ORDER BY data DESC LIMIT 1))";
                $stmt = $conexao->prepare($sql);
                $stmt->bind_param("sssi", $tipo_exame, $resultado, $data, $id_pet);

                if ($stmt->execute()) {
                    echo '<p class="success-message">Exame adicionado com sucesso!</p>';
                } else {
                    echo '<p class="error-message">Erro ao adicionar exame: ' . htmlspecialchars($conexao->error) . '</p>';
                }
            }
        } else {
            echo "<p class='error-message'>ID do pet não fornecido.</p>";
        }
        ?>
    </div>
</body>

</html>
