<?php
session_start();
include_once '../config/config.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['email'])) {
    header('Location: index.php');
    exit();
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar se todos os campos foram preenchidos
    if (!empty($_POST['nome_pet']) && !empty($_POST['especie']) && !empty($_POST['raca']) && !empty($_POST['idade']) && !empty($_POST['peso'])) {
        // Obter os dados do formulário
        $nome_pet = $_POST['nome_pet'];
        $especie = $_POST['especie'];
        $raca = $_POST['raca'];
        $idade = $_POST['idade'];
        $peso = $_POST['peso'];
        $observacoes = isset($_POST['observacoes']) ? $_POST['observacoes'] : null;

        // Obter o ID do usuário da sessão
        $id_usuario = $_SESSION['id_usuario'];

        // Inserir os dados no banco de dados
        $stmt = $conexao->prepare("INSERT INTO pets (id_usuario, nome_pet, especie, raca, idade, peso, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssids", $id_usuario, $nome_pet, $especie, $raca, $idade, $peso, $observacoes);
        if ($stmt->execute()) {
            $mensagem = "Pet cadastrado com sucesso.";
        } else {
            $mensagem = "Erro ao cadastrar o pet. Tente novamente.";
        }
        $stmt->close();
    } else {
        // Exibir uma mensagem de erro caso algum campo esteja faltando
        $mensagem = "Por favor, preencha todos os campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Pet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../assets/styles/home.css" />
</head>

<body>
    <header class="bg-orange">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="../assets/img/logo.png" alt="logo" class="img-fluid">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../pages/home.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../pages/agendar_servico.php">Agendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="main-content">
        <section class="container mt-5">
            <h1>Cadastro de Pet</h1>
            <div class="form-container">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="mb-3">
                        <label for="nome_pet" class="form-label">Nome do Pet:</label>
                        <input type="text" class="form-control" id="nome_pet" name="nome_pet" required>
                    </div>
                    <div class="mb-3">
                        <label for="especie" class="form-label">Espécie:</label>
                        <select class="form-select" name="especie" id="especie" required>
                            <option value="" disabled selected>Selecione a espécie</option>
                            <option value="cao">Cão</option>
                            <option value="gato">Gato</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="raca" class="form-label">Raça:</label>
                        <input type="text" class="form-control" id="raca" name="raca" required>
                    </div>
                    <div class="mb-3">
                        <label for="idade" class="form-label">Idade:</label>
                        <input type="number" class="form-control" id="idade" name="idade" required>
                    </div>
                    <div class="mb-3">
                        <label for="peso" class="form-label">Peso:</label>
                        <input type="number" class="form-control" id="peso" name="peso" required>
                    </div>
                    <div class="mb-3">
                        <label for="observacoes" class="form-label">Observações:</label>
                        <textarea class="form-control" id="observacoes" name="observacoes" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Cadastrar Pet</button>
                </form>
                <?php if (isset($mensagem)) : ?>
                    <div class="alert alert-danger mt-3" role="alert">
                        <?php echo $mensagem; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <footer class="bg-orange text-white">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Links Úteis</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Serviços</a></li>
                        <li><a href="#">Agendamentos</a></li>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Contato</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contato</h5>
                    <p>Endereço: Rua dos Animais, 123</p>
                    <p>Telefone: (XX) XXXX-XXXX</p>
                    <p>Email: contato@patinhasplanet.com</p>
                </div>
                <div class="col-md-4">
                    <h5>Redes Sociais</h5>
                    <ul class="list-unstyled">
                        <li><a href="#"><i class="fab fa-facebook-f"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                        < <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12 text-center">
                    <p>&copy; <?php echo date("Y"); ?> Patinhas Planet. Todos os direitos reservados.</p>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>