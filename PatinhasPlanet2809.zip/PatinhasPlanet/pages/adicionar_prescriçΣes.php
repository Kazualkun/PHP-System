<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Prescrição</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 20px;
        }

        header {
            background-color: #fff;
            padding: 20px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn {
            display: inline-block;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 15px;
            border-radius: 4px;
            text-decoration: none;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php
        // Incluir arquivo de configuração do banco de dados
        include('../config/config.php');
        session_start();

        // Verificar se o veterinário está logado
        if (!isset($_SESSION['id_usuario'])) {
            header("Location: login.php");
            exit();
        }

        // Recebe o ID do pet via GET
        $id_pet = $_GET['id_pet'] ?? null;

        if ($id_pet) {
            // Consulta para obter o nome do pet
            $sql_pet = "SELECT nome_pet FROM pets WHERE id_pet = ?";
            $stmt_pet = $conexao->prepare($sql_pet);
            $stmt_pet->bind_param("i", $id_pet);
            $stmt_pet->execute();
            $result_pet = $stmt_pet->get_result();

            if ($result_pet->num_rows > 0) {
                $pet = $result_pet->fetch_assoc();
                $nome_pet = htmlspecialchars($pet['nome_pet']);

                // Cabeçalho com navegação
                echo '<header>
                    <h1>Adicionar Prescrição para ' . $nome_pet . '</h1>
                    <nav>
                        <a href="prontuarios.php?id_pet=' . htmlspecialchars($id_pet) . '">Prontuários</a>
                        <a href="estoque.php">Estoque</a>
                        <a href="logout.php">Logout</a>
                    </nav>
                  </header>';

                // Verifica se o formulário foi enviado
                if ($_SERVER["REQUEST_METHOD"] === "POST") {
                    // Recebe os dados do formulário
                    $medicamento = $_POST['medicamento'] ?? '';
                    $dosagem = $_POST['dosagem'] ?? '';
                    $frequencia = $_POST['frequencia'] ?? '';
                    $duracao = $_POST['duracao'] ?? '';
                    $data = $_POST['data'] ?? date('Y-m-d');

                    // Valida os dados
                    if ($medicamento && $dosagem && $frequencia && $duracao) {
                        // Insere a prescrição no banco de dados
                        $sql = "INSERT INTO prescricoes (id_prontuario, medicamento, dosagem, frequencia, duracao, data) VALUES (?, ?, ?, ?, ?, ?)";
                        $stmt = $conexao->prepare($sql);

                        if ($stmt) {
                            $id_prontuario = $_GET['id_prontuario']; // Supondo que você tenha o ID do prontuário
                            $stmt->bind_param("isssss", $id_prontuario, $medicamento, $dosagem, $frequencia, $duracao, $data);
                            
                            if ($stmt->execute()) {
                                echo "<p>Prescrição adicionada com sucesso!</p>";
                            } else {
                                echo "<p>Erro ao adicionar prescrição: " . htmlspecialchars($stmt->error) . "</p>";
                            }
                        } else {
                            echo "<p>Erro ao preparar a consulta: " . htmlspecialchars($conexao->error) . "</p>";
                        }
                    } else {
                        echo "<p>Por favor, preencha todos os campos.</p>";
                    }
                }
            } else {
                echo "<p>Pet não encontrado.</p>";
            }
        ?>

            <form id="prescricaoForm" action="adicionar_prescricoes.php?id_pet=<?php echo htmlspecialchars($id_pet); ?>" method="post">
                <div class="form-group">
                    <label>Medicamento:</label>
                    <input type="text" name="medicamento" required>
                </div>

                <div class="form-group">
                    <label>Dosagem:</label>
                    <input type="text" name="dosagem" required>
                </div>

                <div class="form-group">
                    <label>Frequência:</label>
                    <input type="text" name="frequencia" required>
                </div>

                <div class="form-group">
                    <label>Duração:</label>
                    <input type="text" name="duracao" required>
                </div>

                <div class="form-group">
                    <label>Data:</label>
                    <input type="date" name="data" value="<?php echo date('Y-m-d'); ?>" required>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn">Adicionar Prescrição</button>
                </div>
            </form>

            <?php
            echo '</div>'; // Fecha o container
        } else {
            echo "<p>ID do pet não fornecido.</p>";
        }
        ?>
    </div>
</body>

</html>
