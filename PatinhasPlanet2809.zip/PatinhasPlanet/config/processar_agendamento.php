<?php
// Inclua o arquivo de configuração do banco de dados
include_once 'config.php';

// Verifica se os dados do formulário foram enviados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recebe e filtra os dados do formulário
    $data = $_POST['data'];
    $hora = $_POST['hora'];
    $servico = $_POST['servico'];

    // Verifica se a data e hora estão no formato correto
    if (!strtotime($data) || !strtotime($hora)) {
        echo "Formato de data ou hora inválido";
        exit();
    }

    // Verifica se o horário já está ocupado
    $sql = "SELECT * FROM eventos WHERE data = '$data' AND hora = '$hora'";
    $result = $conexao->query($sql);
    if ($result->num_rows > 0) {
        echo "Este horário já está ocupado. Por favor, escolha outro horário.";
        exit();
    }

    // Insere o evento no banco de dados
    $sql = "INSERT INTO eventos (data, hora, servico) VALUES ('$data', '$hora', '$servico')";
    if ($conexao->query($sql) === TRUE) {
        echo "Serviço agendado com sucesso!";
    } else {
        echo "Erro ao agendar o serviço: " . $conexao->error;
    }
} else {
    echo "Erro: método de requisição inválido";
}
?>
