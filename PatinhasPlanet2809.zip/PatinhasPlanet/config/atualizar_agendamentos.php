<?php
include_once '../config/config.php';

// Atualizar status dos agendamentos para 'concluido' onde a data já passou
$query = "UPDATE agendamentos SET status = 'concluido' WHERE data < CURDATE() AND status != 'concluido'";
if ($conexao->query($query) === TRUE) {
    echo "Agendamentos atualizados com sucesso.";
} else {
    echo "Erro ao atualizar agendamentos: " . $conexao->error;
}
$conexao->close();
?>
