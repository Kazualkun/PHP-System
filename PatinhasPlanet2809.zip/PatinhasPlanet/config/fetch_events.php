<?php
session_start();
include_once '../config.php';

$id_cliente = isset($_SESSION['id_usuario']) ? $_SESSION['id_usuario'] : null;

$stmt = $conexao->prepare("SELECT a.id_agendamento, a.data_hora, a.tipo_servico, p.nome_pet FROM agendamentos a JOIN pets p ON a.id_pet = p.id_pet WHERE p.id_usuario = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

$events = array();
while ($row = $result->fetch_assoc()) {
    $events[] = array(
        'id' => $row['id_agendamento'],
        'title' => $row['nome_pet'] . ' - ' . $row['tipo_servico'],
        'start' => $row['data_hora'],
        'color' => ($row['tipo_servico'] == 'banho') ? '#ff9f89' : '#89cff0',
    );
}

$stmt->close();
echo json_encode($events);
?>
