<?php
// Incluir o arquivo de configuração do banco de dados
include_once('config.php');

// Verificar se o método de requisição é POST (ou seja, se o formulário foi enviado)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar se o parâmetro "acao" foi enviado
    if (isset($_POST["acao"])) {
        $acao = $_POST["acao"];

        // Executar a ação correspondente
        switch ($acao) {
            case "ler_eventos":
                // Consultar o banco de dados para ler os eventos
                $sql = "SELECT * FROM eventos";
                $result = $conexao->query($sql);
                $eventos = [];

                // Converter os resultados em um array
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $eventos[] = $row;
                    }
                }

                // Enviar os eventos como JSON para o JavaScript
                echo json_encode($eventos);
                break;

            case "alterar_evento":
                // Verificar se os parâmetros necessários foram enviados
                if (isset($_POST["id"]) && isset($_POST["title"]) && isset($_POST["start"]) && isset($_POST["end"])) {
                    $id = $_POST["id"];
                    $title = $_POST["title"];
                    $start = $_POST["start"];
                    $end = $_POST["end"];

                    // Atualizar o evento no banco de dados
                    $sql = "UPDATE eventos SET title='$title', start='$start', end='$end' WHERE id=$id";
                    $conexao->query($sql);
                    echo "Evento atualizado com sucesso!";
                } else {
                    echo "Parâmetros insuficientes!";
                }
                break;

            case "apagar_evento":
                // Verificar se o parâmetro "id" foi enviado
                if (isset($_POST["id"])) {
                    $id = $_POST["id"];

                    // Apagar o evento do banco de dados
                    $sql = "DELETE FROM eventos WHERE id=$id";
                    $conexao->query($sql);
                    echo "Evento apagado com sucesso!";
                } else {
                    echo "ID do evento não especificado!";
                }
                break;

            default:
                echo "Ação não reconhecida!";
        }
    } else {
        echo "Nenhuma ação especificada!";
    }
}
?>
