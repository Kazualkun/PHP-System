<?php
    $dbhost = 'localhost';
    $username = 'root';
    $dbPassword = '';
    $dbName = 'PatinhasPlanet';

    $conexao = new mysqli($dbhost, $username, $dbPassword, $dbName);

    if($conexao -> connect_error){
        echo "ERRO";
    }
    else{
        echo "Conectado";
    }
?>