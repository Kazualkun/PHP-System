<?php
session_start();

if (isset($_POST['submit']) && !empty($_POST['nome']) && !empty($_POST['senha'])) {
    include_once('../config/config.php');

    // Escape dos dados para evitar SQL Injection
    $nomeEmail = mysqli_real_escape_string($conexao, $_POST['nome']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);

    // Verifica se o usuário usou email ou nome para logar
    $sql = "SELECT * FROM Usuarios WHERE (email = '$nomeEmail' OR nome = '$nomeEmail') AND senha = '$senha'";
    $result = $conexao->query($sql);

    if (mysqli_num_rows($result) < 1) {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        $_SESSION['login_error'] = 'Erro ao fazer login. Verifique suas credenciais.';
        header('Location: ../pages/login.php');
        exit();
    } else {
        $user = $result->fetch_assoc();

        // Armazenar as informações do usuário na sessão
        $_SESSION['email'] = $user['email'];
        $_SESSION['nome'] = $user['nome'];
        $_SESSION['tipo_usuario'] = $user['tipo']; // Alterado para 'tipo_usuario'
        $_SESSION['id_usuario'] = $user['id_usuario']; // ID do usuário
        $_SESSION['crmv'] = $user['crmv']; // Adiciona CRMV se aplicável

        // Redireciona baseado no tipo de usuário
        $base_url = 'http://localhost/PatinhasPlanet/pages/';
        switch ($user['tipo']) {
            case 'administrador':
                $redirect_url = $base_url . 'administrador.php';
                break;
            case 'funcionario':
                $redirect_url = $base_url . 'funcionario.php';
                break;
            case 'veterinario':
                $redirect_url = $base_url . 'prontuario.php';
                break;
            case 'cliente':
            default:
                $redirect_url = $base_url . 'home.php';
                break;
        }

        header('Location: ' . $redirect_url);
        exit();
    }

} else {
    $_SESSION['login_error'] = 'Por favor, preencha todos os campos.';
    header('Location: ../pages/login.php');
    exit();
}
?>
